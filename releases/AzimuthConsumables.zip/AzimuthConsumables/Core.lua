local ADDON, ns = ...
local unpack = unpack or table.unpack
local M = ns.Model
local W = ns.Weapons
local db, char, account, positionStore, bar, picker
local buttons, items, itemByID, auras = {}, {}, {}, {}
local auraReadable, initialized = true, false
local requested, metadata, bagSummary = {}, {}, {}
local weapons = { effects = {}, readable = false }
local pendingWeapon, pendingClassWeapon, layoutSignature, appliedGlow
local queueLayout, activateProfile
local HEADER_HEIGHT, HANDLE_HEIGHT = 24, 12
local EXPRESSWAY = [[Interface\AddOns\EllesmereUI\media\fonts\Expressway.TTF]]
local FOOD_AND_DRINK = 5
local BATTLE_SHOUT_RANKS = { 25289, 11551, 11550, 11549, 6192, 5242, 6673 }
local BACKGROUND, GLOW = { 0.025, 0.04, 0.06 }, { 1, 0.72, 0.16 }
local locale = GetLocale()
local englishTooltips = locale == "enUS" or locale == "enGB"

local function secret(value)
    return issecretvalue and issecretvalue(value) or false
end

local function read(value)
    if secret(value) then return nil end
    return value
end

local function combat()
    return InCombatLockdown and InCombatLockdown()
end

local function say(text)
    print("|cff61d9c4Azimuth Consumables:|r " .. text)
end

-- Restricted combat scans retain the last readable timestamps.
local function scanAuras()
    local previous = auras
    auras, auraReadable = {}, true
    local api = C_UnitAuras and C_UnitAuras.GetAuraDataByIndex
    if not api then auraReadable = false end
    for i = 1, api and 255 or 0 do
        local ok, aura = pcall(C_UnitAuras.GetAuraDataByIndex, "player", i, "HELPFUL")
        if not ok or secret(aura) then auraReadable = false; break end
        if not aura then break end
        local id, name = read(aura.spellId), read(aura.name)
        if not id or not name then
            auraReadable = false
        else
            local expires = read(aura.expirationTime)
            if expires == nil then
                auraReadable = false
            else
                auras[#auras + 1] = {
                    spellID = id, name = name, expires = expires,
                    duration = read(aura.duration), icon = read(aura.icon),
                }
            end
        end
    end
    auras = M.PreserveEffects(previous, auras, auraReadable, combat())
end

local function recoveryFood(id)
    if combat() or not (C_TooltipInfo and C_TooltipInfo.GetItemByID) then return end
    local ok, tooltip = pcall(C_TooltipInfo.GetItemByID, id)
    if not ok or secret(tooltip) or not tooltip or not read(tooltip.lines) then return end
    local lines = {}
    for _, line in ipairs(tooltip.lines) do
        if secret(line) or secret(line.leftText) then return end
        if type(line.leftText) == "string" then lines[#lines + 1] = line.leftText end
    end
    if #lines > 0 then return M.IsRecoveryFood(lines) end
end

local function scanBags()
    local slots = {}
    bagSummary = {}
    if not (C_Container and C_Item) then return end
    for bag = 0, (NUM_BAG_SLOTS or 4) do
        for slot = 1, (C_Container.GetContainerNumSlots(bag) or 0) do
            local info = C_Container.GetContainerItemInfo(bag, slot)
            local id = info and read(info.itemID)
            if id then
                local cached = metadata[id]
                if not cached then
                    local _, _, _, _, icon, classID, subClassID = C_Item.GetItemInfoInstant(id)
                    local name = C_Item.GetItemInfo(id)
                    local spellName, spellID = C_Item.GetItemSpell(id)
                    cached = { id = id, name = name or ("Item " .. id), icon = icon, classID = classID,
                        subClassID = subClassID, spellName = spellName, spellID = spellID }
                    if name then metadata[id] = cached end
                    if (not name or not classID) and not requested[id] and C_Item.RequestLoadItemDataByID then
                        requested[id] = true
                        C_Item.RequestLoadItemDataByID(id)
                    end
                end
                local summary = bagSummary[id]
                if not summary then
                    summary = {}
                    for key, value in pairs(cached) do summary[key] = value end
                    summary.count = 0
                    bagSummary[id] = summary
                end
                summary.count = summary.count + (read(info.stackCount) or 0)
                if id == M.SleepingBag or cached.classID == 0 or db.mappings[id] then
                    if englishTooltips and db.excludeRecoveryFood and cached.classID == 0 and cached.subClassID == FOOD_AND_DRINK
                        and cached.spellID and cached.recoveryFood == nil then
                        cached.recoveryFood = recoveryFood(id)
                    end
                    summary.recoveryFood = cached.recoveryFood
                    slots[#slots + 1] = {
                        id = id, count = read(info.stackCount) or 0, name = cached.name,
                        icon = cached.icon, classID = cached.classID, subClassID = cached.subClassID,
                        spellName = cached.spellName, spellID = cached.spellID,
                        recoveryFood = cached.recoveryFood,
                        weapon = W.IsCandidate(cached),
                    }
                end
            end
        end
    end
    items, itemByID = M.Items(slots, db), {}
    for _, item in ipairs(items) do itemByID[item.id] = item end
    for _, buff in ipairs(ns.ClassBuffs.Items(db, auras, M.Effect, GetTime(), weapons)) do
        items[#items + 1] = buff
        itemByID[buff.id] = buff
    end
end

local function setTextFont(text, size, flags, fallback)
    local media = LibStub and LibStub("LibSharedMedia-3.0", true)
    local registered = media and media:Fetch("font", "Expressway", true)
    if registered then
        local ok, applied = pcall(text.SetFont, text, registered, size, flags)
        if ok and applied then return end
    end
    local ok, applied = pcall(text.SetFont, text, EXPRESSWAY, size, flags)
    if not (ok and applied) then text:SetFont(fallback, size, flags) end
end

local function label(parent, size, point, x, y)
    local text = parent:CreateFontString(nil, "OVERLAY")
    setTextFont(text, size, "OUTLINE", STANDARD_TEXT_FONT)
    text:SetPoint(point, parent, point, x, y)
    return text
end

local function closePicker()
    if picker then picker:Hide() end
end

local function pollWeapons()
    local snapshot = W.Read(GetTime())
    snapshot.effects = M.PreserveEffects(weapons.effects, snapshot.effects, snapshot.readable, combat())
    weapons = snapshot
    if pendingClassWeapon then
        if GetTime() > pendingClassWeapon.deadline then pendingClassWeapon = nil
        elseif pendingClassWeapon.success and W.Learn(pendingClassWeapon.before, weapons,
            1, 0, db, pendingClassWeapon.id) then
            pendingClassWeapon = nil
        end
    end
    if pendingWeapon then
        if GetTime() > pendingWeapon.deadline then pendingWeapon = nil
        elseif C_Item and C_Item.GetItemCount then
            local count = read(C_Item.GetItemCount(pendingWeapon.id, false, false))
            if type(count) == "number" and W.Learn(pendingWeapon.before, weapons,
                pendingWeapon.count, count, db, pendingWeapon.id) then pendingWeapon = nil end
        end
    end
end

local rebuild
local function openPicker(item)
    if combat() then say("Link buffs after leaving combat."); return end
    scanAuras()
    pollWeapons()
    if not picker then
        picker = CreateFrame("Frame", "AzimuthConsumablesBuffPicker", UIParent, "BackdropTemplate")
        picker:SetSize(330, 380)
        picker:SetPoint("CENTER")
        picker:SetFrameStrata("DIALOG")
        picker:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8", edgeFile = "Interface\\Buttons\\WHITE8X8", edgeSize = 1 })
        picker:SetBackdropColor(0.04, 0.06, 0.09, 0.98)
        picker:SetBackdropBorderColor(0.25, 0.7, 0.6, 1)
        picker.title = label(picker, 12, "TOPLEFT", 12, -15)
        local close = CreateFrame("Button", nil, picker, "UIPanelCloseButton")
        close:SetPoint("TOPRIGHT", 0, 0)
        close:SetScript("OnClick", closePicker)
        local scroll = CreateFrame("ScrollFrame", nil, picker, "UIPanelScrollFrameTemplate")
        scroll:SetPoint("TOPLEFT", 10, -65)
        scroll:SetPoint("BOTTOMRIGHT", -32, 12)
        local content = CreateFrame("Frame", nil, scroll)
        content:SetSize(280, 1)
        scroll:SetScrollChild(content)
        picker.content, picker.rows = content, {}
        label(picker, 10, "TOPLEFT", 12, -40):SetText("Choose the buff this item provides. Scroll for more.")
        table.insert(UISpecialFrames, "AzimuthConsumablesBuffPicker")
    end
    picker.title:SetText((item.name or item.spellName) .. " - link effect")
    picker.itemID = item.id
    local choices = { { name = "Automatic matching (reset)", reset = true } }
    for _, effect in ipairs(weapons.effects) do
        choices[#choices + 1] = {
            name = (effect.hand == "main" and "Main hand" or "Off hand") .. ": weapon enchant " .. effect.enchantID,
            weapon = true, hand = effect.hand, enchantID = effect.enchantID,
        }
    end
    local seen = {}
    for _, aura in ipairs(auras) do
        if not (item.classBuff and item.weapon) and not seen[aura.spellID] then
            seen[aura.spellID] = true
            choices[#choices + 1] = aura
        end
    end
    for i, choice in ipairs(choices) do
        local row = picker.rows[i]
        if not row then
            row = CreateFrame("Button", nil, picker.content, "UIPanelButtonTemplate")
            row:SetSize(275, 25)
            row:SetPoint("TOPLEFT", 0, -(i - 1) * 29)
            local text = row:GetFontString()
            local font, size, flags = text:GetFont()
            setTextFont(text, size, flags, font)
            row:SetScript("OnClick", function(self)
                if combat() then say("Link buffs after leaving combat."); return end
                if self.choice.reset then db.mappings[picker.itemID] = nil
                elseif self.choice.weapon then db.mappings[picker.itemID] = {
                    weapon = true, hand = self.choice.hand, enchantID = self.choice.enchantID,
                }
                else db.mappings[picker.itemID] = { self.choice.spellID } end
                say("Updated effect link. Use /azc map for multiple buff IDs.")
                closePicker()
                rebuild()
            end)
            picker.rows[i] = row
        end
        row.choice = choice
        row:SetText(choice.name .. (choice.spellID and (" (" .. choice.spellID .. ")") or ""))
        row:Show()
    end
    for i = #choices + 1, #picker.rows do picker.rows[i]:Hide() end
    picker.content:SetHeight(math.max(1, #choices * 29))
    picker:Show()
end

local function isWeaponConsumable(item)
    if not item then return false end
    if item.classBuff then return false end
    local mapping = db.mappings[item.id]
    return item.weapon or db.weaponEnchants[item.id] or (mapping and mapping.weapon)
end

local function newButton()
    local b = CreateFrame("Button", nil, bar, "SecureActionButtonTemplate")
    b:SetSize(db.iconSize, db.iconSize)
    b:RegisterForClicks("AnyUp", "AnyDown")
    b:SetAttribute("useOnKeyDown", false)
    b:SetAttribute("type1", "item")
    b.icon = b:CreateTexture(nil, "ARTWORK")
    b.icon:SetAllPoints()
    b.icon:SetTexCoord(0.08, 0.92, 0.08, 0.92)
    b.cooldown = CreateFrame("Cooldown", nil, b, "CooldownFrameTemplate")
    b.cooldown:SetAllPoints()
    if b.cooldown.SetHideCountdownNumbers then b.cooldown:SetHideCountdownNumbers(true) end
    -- Plain textures can animate during lockdown; no secure visibility or
    -- attributes are changed when a timer updates.
    b.glow = CreateFrame("Frame", nil, b)
    b.glowEdges = {}
    b.glow:SetPoint("TOPLEFT", -3, 3)
    b.glow:SetPoint("BOTTOMRIGHT", 3, -3)
    for _, edge in ipairs({ "TOP", "BOTTOM", "LEFT", "RIGHT" }) do
        local tex = b.glow:CreateTexture(nil, "OVERLAY")
        tex:SetColorTexture(unpack(db.glowColor))
        b.glowEdges[#b.glowEdges + 1] = tex
        if edge == "TOP" or edge == "BOTTOM" then
            tex:SetHeight(3); tex:SetPoint(edge .. "LEFT"); tex:SetPoint(edge .. "RIGHT")
        else
            tex:SetWidth(3); tex:SetPoint("TOP" .. edge); tex:SetPoint("BOTTOM" .. edge)
        end
    end
    b.count = label(b, 11, "TOPRIGHT", -2, -2)
    b.time = label(b, 10, "BOTTOM", 0, 2)
    b.status = label(b, 8, "CENTER", 0, 0)
    b.status:SetShadowColor(0, 0, 0, 1)
    b.status:SetShadowOffset(1, -1)
    b:SetScript("OnEnter", function(self)
        GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
        if self.item.classBuff then
            GameTooltip:SetSpellByID(self.item.spellID)
            local hint = self.item.castSpell and ("Left-click: cast " .. self.item.spellName .. " on yourself.")
                or "This buff is unavailable to this loadout."
            if self.item.weapon then
                hint = "Left-click to imbue your weapon. Right-click to link an existing weapon enchant."
            end
            GameTooltip:AddLine(hint, 0.4, 1, 0.8, true)
        else
            GameTooltip:SetItemByID(self.item.id)
            if self.item.id == M.SleepingBag then
                GameTooltip:AddLine("Left-click to place the bag. Glow reminds you to refresh Well-Rested.", 0.4, 1, 0.8, true)
            else
                GameTooltip:AddLine("Left-click: use. Right-click: link active buff.", 0.4, 1, 0.8, true)
            end
            GameTooltip:AddLine("Shift-right-click: hide this item. /azc restore to restore.", 0.7, 0.7, 0.7, true)
        end
        if self.statusCode then
            local status = M.Statuses[self.statusCode]
            GameTooltip:AddLine(status.label, unpack(status.color))
        end
        if self.cachedTimer then
            GameTooltip:AddLine("Estimated from the last readable timer. Refreshes and removals are confirmed when data becomes readable.", 1, 0.8, 0.4, true)
        end
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave", function() GameTooltip:Hide() end)
    b:HookScript("PreClick", function(self, mouse, down)
        if mouse == "LeftButton" and not down and self.item and self.item.classBuff
            and self.item.weapon and self.item.castSpell then
            pollWeapons()
            pendingClassWeapon = { id = self.item.id, spellID = self.item.castSpell,
                before = weapons, deadline = GetTime() + 15 }
        end
        if mouse ~= "LeftButton" or down or not isWeaponConsumable(self.item) then return end
        pollWeapons()
        local count = C_Item.GetItemCount and read(C_Item.GetItemCount(self.item.id, false, false))
        if type(count) == "number" then
            pendingWeapon = { id = self.item.id, count = count, before = weapons, deadline = GetTime() + 45 }
        end
    end)
    b:HookScript("PostClick", function(self, mouse, down)
        if down or not self.item then return end
        if mouse == "LeftButton" then
            local item = itemByID[self.item.id]
            if item and item.count > 0 and isWeaponConsumable(item) and not combat() and ToggleCharacter then
                -- onlyShow keeps the equipment tab open on repeated clicks.
                ToggleCharacter("PaperDollFrame", true)
            end
            return
        end
        if mouse ~= "RightButton" or (self.item.classBuff and not self.item.weapon) then return end
        if IsShiftKeyDown() then
            if self.item.classBuff then db.disabledBuffs[self.item.id] = true
            else db.hidden[self.item.id] = true end
            rebuild()
            if ns.RefreshOptions then ns.RefreshOptions() end
        elseif self.item.id ~= M.SleepingBag then
            openPicker(self.item)
        end
    end)
    return b
end

local function paint()
    local now = GetTime()
    for _, b in ipairs(buttons) do
        if b:IsShown() and b.item then
            local current = itemByID[b.item.id]
            local item = current or b.item
            local start, duration, enabled = 0, 0, 1
            if not item.classBuff and C_Container.GetItemCooldown then
                start, duration, enabled = C_Container.GetItemCooldown(item.id)
            elseif item.castSpell and C_Spell.GetSpellCooldown then
                local ok, cooldown = pcall(C_Spell.GetSpellCooldown, item.castSpell)
                if ok and not secret(cooldown) and cooldown then
                    start, duration = cooldown.startTime, cooldown.duration
                    enabled = read(cooldown.isEnabled) == false and 0 or 1
                end
            end
            start, duration, enabled = read(start) or 0, read(duration) or 0, read(enabled)
            item.cooldownEnd = duration > 1.5 and start + duration or nil
            local state = M.State(item, auras, db, now, auraReadable, weapons)
            b.count:SetText(item.classBuff and "" or (current and current.count or 0))
            if item.classBuff and not item.castSpell and not state.active then state.text = "N/A" end
            b.time:SetText(state.text)
            local usable, noResource
            if item.classBuff then
                if item.castSpell then usable, noResource = C_Spell.IsSpellUsable(item.castSpell) end
            elseif item.id == M.SleepingBag then
                usable = not item.cooldownEnd or item.cooldownEnd <= now
            else
                usable, noResource = C_Item.IsUsableItem(item.id)
            end
            b.statusCode = M.Status(item, state, now, read(usable), read(noResource), enabled)
            local status = M.Statuses[b.statusCode]
            b.cachedTimer = state.cached
            b.status:SetText(state.cached and "~" or status.badge)
            b.status:SetTextColor(unpack(status.color))
            b.time:SetTextColor(unpack(status.color))
            local glow = state.glow and (b.statusCode == "MISSING" or b.statusCode == "EXPIRING")
            if item.id == M.SleepingBag then
                glow = glow and current and current.count > 0 and enabled ~= 0 and read(usable)
            end
            if item.classBuff and not item.castSpell then glow = false end
            b.glow:SetAlpha(glow and (0.55 + 0.45 * math.sin(now * 4) ^ 2) or 0)
            b.icon:SetDesaturated(not current or item.count == 0 or enabled == 0 or not read(usable))
            if duration > 1.5 then b.cooldown:SetCooldown(start, duration) else b.cooldown:Clear() end
            if item.count == 0 and not state.active and queueLayout and not combat() then queueLayout() end
        end
    end
end

rebuild = function()
    if not initialized then return end
    if not combat() then activateProfile() end
    pollWeapons()
    scanBags()
    -- Keep an active timer after consuming the last copy; show a dim icon and
    -- zero count until the effect expires. It then leaves the bar out of combat.
    for _, button in ipairs(buttons) do
        local previous = button.item
        if previous and not previous.classBuff and not M.IsExcluded(metadata[previous.id] or previous, db)
            and not itemByID[previous.id]
            and M.Effect(previous, auras, db, GetTime(), weapons) then
            local tracked = {}
            for k, v in pairs(previous) do tracked[k] = v end
            tracked.count = 0
            items[#items + 1] = tracked
            itemByID[tracked.id] = tracked
        end
    end
    if combat() then paint(); return end
    bar.title:SetShown(not db.hideTitle)
    local background = db.backgroundColor
    bar:SetBackdropColor(background[1], background[2], background[3], 0.88)
    if appliedGlow ~= db.glowColor then
        appliedGlow = db.glowColor
        for _, button in ipairs(buttons) do
            for _, edge in ipairs(button.glowEdges) do edge:SetColorTexture(unpack(appliedGlow)) end
        end
    end
    -- Keep picker contents stable while bag/item-data events arrive. Rebuilding
    -- the bar must not close or repurpose a row the player is about to click.
    local p = positionStore.position or { "CENTER", "CENTER", 0, -200 }
    local signatureParts = { tostring(db.scale), tostring(db.disabled), tostring(db.hideTitle), table.concat(p, ":"),
        db.iconSize, db.spacing, db.iconsPerLine, tostring(db.vertical), db.timerTextSize, db.countTextSize }
    for _, item in ipairs(items) do
        signatureParts[#signatureParts + 1] = tostring(item.id)
        if item.classBuff then signatureParts[#signatureParts + 1] = "rank:" .. tostring(item.castSpell) end
    end
    local signature = table.concat(signatureParts, "|")
    if signature == layoutSignature then
        for _, b in ipairs(buttons) do if b.item and itemByID[b.item.id] then b.item = itemByID[b.item.id] end end
        paint()
        return
    end
    layoutSignature = signature
    local headerHeight = db.hideTitle and HANDLE_HEIGHT or HEADER_HEIGHT
    local itemTop = headerHeight + 3
    local layout = M.Layout(#items, db)
    local width = layout.width
    if not db.hideTitle then width = math.max(width, math.ceil(bar.title:GetStringWidth()) + 16) end
    local height = itemTop + layout.height
    if #items == 0 then
        width = math.max(width, math.ceil(bar.empty:GetStringWidth()) + 14)
        height = headerHeight + 24
    end
    bar.header:SetHeight(headerHeight)
    bar:SetSize(width, height)
    bar:ClearAllPoints()
    bar:SetPoint(p[1], UIParent, p[2], p[3], p[4])
    bar:SetScale(db.scale)
    for i, item in ipairs(items) do
        local b = buttons[i]
        if not b then b = newButton(); buttons[i] = b end
        if not b.item or b.item.id ~= item.id or b.item.castSpell ~= item.castSpell then
            local action = item.castSpell and "spell" or (not item.classBuff and "item" or nil)
            b:SetAttribute("type1", action)
            b:SetAttribute("spell1", item.castSpell)
            b:SetAttribute("unit1", item.classBuff and not item.weapon and "player" or nil)
            b:SetAttribute("item1", not item.classBuff and ("item:" .. item.id) or nil)
        end
        b.item = item
        b:SetSize(layout.size, layout.size)
        setTextFont(b.time, db.timerTextSize, "OUTLINE", STANDARD_TEXT_FONT)
        setTextFont(b.count, db.countTextSize, "OUTLINE", STANDARD_TEXT_FONT)
        b.time:SetWidth(layout.size - 2)
        b.time:SetWordWrap(false)
        b.count:SetWidth(layout.size - 4)
        b.count:SetJustifyH("RIGHT")
        b.count:SetWordWrap(false)
        b.icon:SetTexture(item.icon or 134400)
        b:ClearAllPoints()
        local column, row = (i - 1) % layout.perLine, math.floor((i - 1) / layout.perLine)
        if db.vertical then column, row = row, column end
        b:SetPoint("TOPLEFT", layout.gap + column * (layout.size + layout.gap),
            -itemTop - row * (layout.size + layout.gap))
        b:Show()
    end
    for i = #items + 1, #buttons do
        local b = buttons[i]
        if b.item then
            b:SetAttribute("item1", nil)
            b:SetAttribute("spell1", nil)
            b:SetAttribute("unit1", nil)
            b:SetAttribute("type1", nil)
            b.item = nil
            b:Hide()
        end
    end
    bar.empty:SetShown(#items == 0)
    bar:SetShown(not db.disabled)
    paint()
end

local function savedColor(value, fallback)
    local color = {}
    for channel = 1, 3 do
        local component = type(value) == "table" and tonumber(value[channel])
        color[channel] = math.max(0, math.min(1, component or fallback[channel]))
    end
    return color
end

local function normalizeSettings()
    db.hidden = type(db.hidden) == "table" and db.hidden or {}
    db.mappings = type(db.mappings) == "table" and db.mappings or {}
    db.weaponEnchants = type(db.weaponEnchants) == "table" and db.weaponEnchants or {}
    for id, mapping in pairs(db.mappings) do
        if type(mapping) ~= "table" then db.mappings[id] = nil end
    end
    for id, ids in pairs(db.weaponEnchants) do
        if type(ids) ~= "table" then db.weaponEnchants[id] = nil end
    end
    local p = positionStore.position
    local anchors = { CENTER = true, TOP = true, BOTTOM = true, LEFT = true, RIGHT = true,
        TOPLEFT = true, TOPRIGHT = true, BOTTOMLEFT = true, BOTTOMRIGHT = true }
    if type(p) ~= "table" or not anchors[p[1]] or not anchors[p[2]]
        or type(p[3]) ~= "number" or type(p[4]) ~= "number" then positionStore.position = nil end
    db.scale = M.Scale(db.scale)
    db.backgroundColor = savedColor(db.backgroundColor, BACKGROUND)
    db.glowColor = savedColor(db.glowColor, GLOW)
    db.excludeRecoveryFood = db.excludeRecoveryFood ~= false
    db.hideUnavailableClassBuffs = db.hideUnavailableClassBuffs ~= false
    db.disabledBuffs = type(db.disabledBuffs) == "table" and db.disabledBuffs or {}
    db.preferredBuffs = type(db.preferredBuffs) == "table" and db.preferredBuffs or {}
    db.refreshThresholds = type(db.refreshThresholds) == "table" and db.refreshThresholds or {}
    db.refreshDefault = M.RefreshSeconds(db.refreshDefault)
    db.iconSize = M.Number(db.iconSize, 40, 24, 80)
    db.spacing = M.Number(db.spacing, 7, 0, 20)
    db.iconsPerLine = M.Number(db.iconsPerLine, 8, 1, 20)
    db.timerTextSize = M.Number(db.timerTextSize, 10, 8, 20)
    db.countTextSize = M.Number(db.countTextSize, 11, 8, 20)
end

activateProfile = function()
    local settings, positions, name = ns.Profiles.Resolve(account, char)
    if settings == db and positionStore == positions then return end
    if ns.CancelOptionsEditing then ns.CancelOptionsEditing() end
    closePicker()
    if ColorPickerFrame then ColorPickerFrame:Hide() end
    db, positionStore = settings, positions
    pendingWeapon, pendingClassWeapon, layoutSignature, appliedGlow = nil, nil, nil, nil
    normalizeSettings()
    ns.ProfileName = name
    if ns.BindOptions then ns.BindOptions(db) end
end

ns.SetProfileMode = function(mode)
    if mode ~= "shared" and mode ~= "character" and mode ~= "spec" then return end
    char.profileMode = mode
    rebuild()
    if ns.RefreshOptions then ns.RefreshOptions() end
end

ns.CopySharedProfile = function()
    if combat() then say("Copy profiles after leaving combat."); return end
    if db == account then return end
    if ns.CancelOptionsEditing then ns.CancelOptionsEditing() end
    if ColorPickerFrame then ColorPickerFrame:Hide() end
    local replacement = ns.Profiles.Copy(account)
    replacement.position = char.position and CopyTable(char.position)
    for key in pairs(db) do db[key] = nil end
    for key, value in pairs(replacement) do db[key] = value end
    normalizeSettings()
    layoutSignature, appliedGlow = nil, nil
    closePicker()
    rebuild()
    if ns.RefreshOptions then ns.RefreshOptions() end
end

local function initialize()
    if initialized or combat() then return end
    AzimuthConsumablesDB = type(AzimuthConsumablesDB) == "table" and AzimuthConsumablesDB or {}
    AzimuthConsumablesCharDB = type(AzimuthConsumablesCharDB) == "table" and AzimuthConsumablesCharDB or {}
    char = AzimuthConsumablesCharDB
    account = AzimuthConsumablesDB
    activateProfile()
    bar = CreateFrame("Frame", "AzimuthConsumablesBar", UIParent, "BackdropTemplate")
    bar:SetMovable(true)
    bar:SetClampedToScreen(true)
    bar:SetBackdrop({ bgFile = "Interface\\Buttons\\WHITE8X8" })
    local header = CreateFrame("Button", nil, bar)
    bar.header = header
    header:SetPoint("TOPLEFT"); header:SetPoint("TOPRIGHT"); header:SetHeight(HEADER_HEIGHT)
    header:RegisterForDrag("LeftButton")
    header:RegisterForClicks("RightButtonUp")
    header:SetScript("OnClick", function() if ns.OpenOptions then ns.OpenOptions() end end)
    bar.title = label(header, 11, "LEFT", 8, 0)
    bar.title:SetText("|cff61d9c4AZIMUTH|r  Consumables")
    header:SetScript("OnDragStart", function() if not combat() and not db.locked then bar:StartMoving() end end)
    local function stopDrag()
        if combat() then return end
        bar:StopMovingOrSizing()
        local point, _, relPoint, x, y = bar:GetPoint()
        positionStore.position = { point, relPoint, x, y }
    end
    header:SetScript("OnDragStop", stopDrag)
    ns.StopDrag = stopDrag
    bar.empty = label(bar, 10, "BOTTOMLEFT", 7, 7)
    bar.empty:SetText("No items")
    local elapsed = 0
    bar:SetScript("OnUpdate", function(_, dt)
        elapsed = elapsed + dt
        if elapsed >= 0.2 then elapsed = 0; pollWeapons(); paint() end
    end)
    initialized = true
    ns.GetSettings = function() return db end
    ns.GetCharacterSettings = function() return char end
    ns.RegisterOptions(db, rebuild, label)
    scanAuras()
    rebuild()
    say("Loaded. Drag the header to move; /azc opens settings.")
end

ns.BuildDebugReport = function(query)
    rebuild()
    local _, class = UnitClass("player")
    local _, spec = ns.Profiles.SpecKey()
    local metadata = C_AddOns and C_AddOns.GetAddOnMetadata or GetAddOnMetadata
    local version = metadata and metadata(ADDON, "Version") or "unknown"
    local statuses = {}
    for _, button in ipairs(buttons) do
        if button:IsShown() and button.item then statuses[button.item.id] = button.statusCode end
    end
    return ns.Diagnostics.Build({
        settings = db, version = version, class = class, profile = ns.ProfileName,
        spec = spec, combat = not not combat(), now = GetTime(), auraReadable = auraReadable,
        weapons = weapons, auras = auras, bags = bagSummary, items = items,
        choices = ns.ClassBuffs.Options(), statuses = statuses, query = query,
    })
end

ns.ShowDebug = function(query)
    ns.Diagnostics.Show(ns.BuildDebugReport(query))
end

SLASH_AZIMUTHCONSUMABLES1 = "/azc"
SlashCmdList.AZIMUTHCONSUMABLES = function(message)
    if not initialized then say("Ready after combat ends."); return end
    local command, args = message:match("^(%S*)%s*(.-)$")
    command = command:lower()
    if command == "debug" then
        local query = args ~= "" and tonumber(args) or nil
        if args ~= "" and (not query or query ~= math.floor(query) or query == 0) then
            say("/azc debug [item ID or base spell ID]")
            return
        end
        ns.ShowDebug(query and math.abs(query))
    elseif command == "" or command == "config" or command == "options" then
        if ns.OpenOptions then ns.OpenOptions() end
    elseif command == "lock" then db.locked = true; say("Position locked.")
    elseif command == "unlock" then db.locked = false; say("Drag the header to move.")
    elseif command == "hide" then db.disabled = true; closePicker(); rebuild()
    elseif command == "show" then db.disabled = false; rebuild()
    elseif command == "restore" then db.hidden = {}; rebuild()
    elseif command == "scale" and tonumber(args) then db.scale = M.Scale(args); rebuild()
    elseif command == "reset" then positionStore.position = nil; db.scale = 1; rebuild()
    elseif command == "map" then
        local idText, spells = args:match("^(%d+)%s+(.+)$")
        if not idText then say("/azc map ITEM_ID BUFF_ID [BUFF_ID ...], auto, main, off, or either"); return end
        local id, ids = tonumber(idText), {}
        if spells == "auto" then db.mappings[id] = nil; db.weaponEnchants[id] = nil
        elseif spells == "main" or spells == "off" or spells == "either" then
            pollWeapons()
            local found
            for _, effect in ipairs(weapons.effects) do
                if spells == "either" or spells == effect.hand then found = effect; break end
            end
            if not found then say("Apply the stone first, then link its active weapon enchant."); return end
            db.mappings[id] = { weapon = true, hand = spells, enchantID = found.enchantID }
        else
            for n in spells:gmatch("%d+") do ids[#ids + 1] = tonumber(n) end
            if #ids == 0 then say("Specify at least one buff spell ID."); return end
            db.mappings[id] = ids
        end
        rebuild()
    elseif command == "buffs" then
        scanAuras()
        for _, aura in ipairs(auras) do say(aura.spellID .. " - " .. aura.name) end
    else
        say("Left-click uses an item; right-click links its active buff; Shift-right-click hides it.")
        say("/azc opens settings for size, colors, locking, and filters.")
        say("/azc debug [item ID or base spell ID] opens a copyable diagnostic report.")
        say("/azc lock | unlock | hide | show | restore | scale 1.2 | reset | buffs")
        say("/azc map ITEM_ID BUFF_ID [BUFF_ID ...] - link custom effects. Glow = missing; countdown = active effect; CD = reuse cooldown.")
    end
    if ns.RefreshOptions then ns.RefreshOptions() end
end

local events = CreateFrame("Frame")
for _, event in ipairs({ "PLAYER_LOGIN", "PLAYER_ENTERING_WORLD", "PLAYER_REGEN_ENABLED", "PLAYER_REGEN_DISABLED",
    "BAG_UPDATE_DELAYED", "BAG_UPDATE_COOLDOWN", "UNIT_AURA", "UNIT_INVENTORY_CHANGED",
    "PLAYER_EQUIPMENT_CHANGED", "ITEM_DATA_LOAD_RESULT", "GET_ITEM_INFO_RECEIVED", "SPELLS_CHANGED",
    "PLAYER_SPECIALIZATION_CHANGED", "ACTIVE_TALENT_GROUP_CHANGED", "UNIT_SPELLCAST_SUCCEEDED" }) do
    events:RegisterEvent(event)
end
local scheduled = false
local function rebuildSoon()
    if scheduled then return end
    scheduled = true
    C_Timer.After(0, function() scheduled = false; rebuild() end)
end
queueLayout = rebuildSoon
events:SetScript("OnEvent", function(_, event, unit, success, spellID)
    if event == "PLAYER_LOGIN" or event == "PLAYER_REGEN_ENABLED" then
        initialize()
        if initialized then scanAuras(); rebuildSoon() end
    elseif not initialized then return
    elseif event == "UNIT_SPELLCAST_SUCCEEDED" then
        if unit == "player" and pendingClassWeapon and not secret(spellID)
            and spellID == pendingClassWeapon.spellID then
            pendingClassWeapon.success = true
            pollWeapons()
            rebuildSoon()
        end
    elseif event == "PLAYER_REGEN_DISABLED" then
        closePicker()
        -- Starting combat automatically stops protected layout changes.
    elseif event == "UNIT_AURA" then
        if secret(unit) then return end
        if unit == "player" then
            scanAuras()
            paint()
            rebuildSoon()
        end
    elseif event == "BAG_UPDATE_COOLDOWN" then paint()
    elseif event == "ITEM_DATA_LOAD_RESULT" or event == "GET_ITEM_INFO_RECEIVED" then
        -- Ignore unrelated item-cache activity. A completed request is removed
        -- before refreshing so cached reads cannot trigger a rebuild storm.
        if not secret(unit) and requested[unit] then
            requested[unit] = nil
            if success then metadata[unit] = nil; rebuildSoon() end
        end
    elseif event == "UNIT_INVENTORY_CHANGED" then
        if not secret(unit) and unit == "player" then pollWeapons(); rebuildSoon() end
    else
        if event == "PLAYER_ENTERING_WORLD" then scanAuras() end
        rebuildSoon()
    end
end)

ns.Refresh, ns.Buttons = rebuild, buttons
